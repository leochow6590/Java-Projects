COMP2396 Assignment 4

Chow Chak Lam Leo 3035566613

1. Put all the .java file in the same directory.

2. Launch 3 command prompts, execute "javac *.java" at one of them.

3. At the same command prompt, execute "java Server".

4. After starting the server, execute "java Client" in the two remaining command prompts respectively.

5. Two GUI should be available now.

6. Players can now enter their names to start the game.

7. The game ends when any player win or draw or left the game.

8. To restart the game, restart of the server and client is required.